import React from 'react';
import '../Body.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const Body = () => {
  return (
    <div className="body-container">
    </div>
  );
};

export default Body;
